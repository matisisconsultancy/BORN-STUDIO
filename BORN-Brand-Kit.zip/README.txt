Born Apparel Studio - Brand kit
Brand book: https://matisisconsultancy.github.io/BORN-STUDIO/

logos-png/   High-resolution PNG, transparent background. For screens, documents, social.
logos-svg/   Vector. For print, embroidery, signage and any size.
animations/  The two animated signatures: MP4 (universal) and WebM.
fonts/       Bodoni Moda (voice), Jost (reading), Space Mono (technical data). SIL Open Font License.

Red is earned: #C4122E, only where BORN is born.
Sketched. Stitched. BORN.
